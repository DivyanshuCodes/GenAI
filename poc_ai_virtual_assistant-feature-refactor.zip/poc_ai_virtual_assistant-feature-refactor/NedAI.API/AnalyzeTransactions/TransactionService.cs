﻿using NedAI.API.Models;
using NedAI.API.VirtualAssistant.Account;
using NedAI.API.VirtualAssistant.Models;
using Newtonsoft.Json;
using OpenAI_API.Chat;
using openai_api_facade;

namespace NedAI.API.AnalyzeTransactions
{
    public class TransactionService : ITransactionService
    {
        private ILogger<TransactionService> _logger;
        private readonly HttpClient _httpClient;
        private readonly IOpenAIApiFacade _openAIApiFacade;
        public TransactionService(ILogger<TransactionService> logger,
                                        IHttpClientFactory httpClientFactory,
                                        AppSettings appSettings,
                                        IOpenAIApiFacade openAIApiFacade)
        {
            _logger = logger;
            _httpClient = httpClientFactory.CreateClient();
            _httpClient.BaseAddress = new Uri($"{appSettings.NedGPTUrl}");
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
            _openAIApiFacade = openAIApiFacade;
        }

        public async Task<List<AnalyzeTransactionsResponse>> AnalyzeTransactionAsync(AnalyzeTransactionsRequest analyzeTransactionsRequest)
        {
            List<AnalyzeTransactionsResponse> analyzeTransactionsResponseList = null;
            try
            {
                // Validate

                if (analyzeTransactionsRequest == null)
                {
                    throw new ArgumentNullException(nameof(analyzeTransactionsRequest));
                }

                // 1. Create System Prompt
                var systemPromptContent = TransactionPrompts.TRANSACTIONS_LIST_PROMPT;

                if(analyzeTransactionsRequest.Categorize)
                {
                    systemPromptContent += $" {TransactionPrompts.CATEGORIZE_TRANSACTIONS_PROMPT}";
                }

                if(analyzeTransactionsRequest.FraudDetection)
                {
                    systemPromptContent += $" {TransactionPrompts.DETECT_FRAUD_TRANSACTIONS_PROMPT}";
                }

                systemPromptContent += $"{TransactionPrompts.FORMAT_JSON_PROMPT}";

                var systemPrompt = new ChatMessage(ChatMessageRole.System, systemPromptContent);

                // 2. Create User Prompt

                var transactionData = File.ReadAllText(@"Data\TransactionData.json");
                var userPrompt = new ChatMessage(ChatMessageRole.User, transactionData);

                var prompts = new List<ChatMessage> { systemPrompt, userPrompt };

                // 3. Send to OpenAPI Chat Completion
                // var gptResponse = await _httpClient.PostAsJsonAsync("/api/gpt/Completion", prompts);
                var gptResponse = await _openAIApiFacade.CreateChatCompletionAsync(prompts, OpenAI_API.Models.Model.ChatGPTTurbo, 0, 1, null, 2000, 0, 0);
                //var responseContent = await gptResponse.Content.ReadAsStringAsync();
                var responseContent = gptResponse.Choices[0].Message.Content;
                // 4. Extract OpenAPI Response Content and return response
                //if (gptResponse.IsSuccessStatusCode)
                //{
                // Read the response content as a string
                    
                //var chatResult = JsonConvert.DeserializeObject<ChatResult>(responseContent);
                //var content = chatResult.Choices.First().Message.Content;
                analyzeTransactionsResponseList = JsonConvert.DeserializeObject<List<AnalyzeTransactionsResponse>>(responseContent);
                //}

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                throw;
            }
            return analyzeTransactionsResponseList;
        }

        public async Task<List<AccountTransaction>> BulkUpdateTransactionsAsync(List<AccountTransaction> accountTransactions)
        {
            List<AccountTransaction> accountTransactionsList = null;
            try
            {
                var serializedTransactions = JsonConvert.SerializeObject(accountTransactions, Formatting.Indented);
                File.WriteAllText(@"Data\TransactionData.json", serializedTransactions);

                return await GetTransactionsAsync();
            }
            catch(Exception) 
            {
                throw;
            }
        }
        private async Task<List<AccountTransaction>> GetTransactionsAsync()
        {
            try
            {
                string jsonData = File.ReadAllText(@"Data\TransactionData.json");
                var transactions = JsonConvert.DeserializeObject<List<AccountTransaction>>(jsonData);
                return transactions;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                throw;
            }
        }
    }
}
