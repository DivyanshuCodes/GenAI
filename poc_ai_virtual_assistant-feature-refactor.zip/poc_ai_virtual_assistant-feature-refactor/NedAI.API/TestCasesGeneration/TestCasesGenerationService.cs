﻿using NedAI.API.Models;
using Newtonsoft.Json;
using OpenAI_API.Chat;
using openai_api_facade;

namespace NedAI.API.TestCasesGeneration
{
    public class TestCasesGenerationService: ITestCasesGenerationService
    {
        private ILogger<TestCasesGenerationService> _logger;
        private readonly HttpClient _httpClient;
        private readonly IOpenAIApiFacade _openAIApiFacade;
        public TestCasesGenerationService(ILogger<TestCasesGenerationService> logger,
                                        IHttpClientFactory httpClientFactory,
                                        AppSettings appSettings,
                                        IOpenAIApiFacade openAIApiFacade)
        {
            _logger = logger;
            _httpClient = httpClientFactory.CreateClient();
            _httpClient.BaseAddress = new Uri($"{appSettings.NedGPTUrl}");
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
            _openAIApiFacade = openAIApiFacade;
        }

        public async Task<List<TestCasesGenerationResponse>> GenerationTestCasesAsync(TestCasesGenerationRequest request)
        {
            var prompts = new List<ChatMessage> {};

            try
            {
                // Validate
                _logger.LogInformation($"Request input: {request}");
                if (request == null || request.conditions == null)
                {
                    throw new ArgumentNullException(nameof(request));
                }

                var noOfTestCaseString = $"\n 6. Generate at least " + request.noOfTestCases + " meaningful, logically sound scenarios. Ensure comprehensive coverage of all conditions and possible permutations.";

                // 1. Create System Prompt
                var promptString = File.ReadAllText(@"Data\TestCasesGeneration1.txt");
                promptString += $"{noOfTestCaseString}";
                prompts.Add(new ChatMessage(ChatMessageRole.System, promptString));
                _logger.LogInformation($"System prompt: {promptString}");

                // 2. Create dynamic prompt based on refinement conditions
                var promptContent = "<conditions>" + request.conditions + "</conditions> \n";

                if (request !=null && request.refinementOptions !=null) {
                    var config = request.refinementOptions;

                    if (config.onlyNegativeScenarios)
                    {
                        promptContent += $" {UserPrompts.NEGATIVE_SCENARIOS_ONLY} ";
                    }
                    if (config.onlyPositiveScenarios)
                    {
                        promptContent += $" {UserPrompts.POSITIVE_SCENARIOS_ONLY}";
                    }
                }

                // 2.Create user prompt
                prompts.Add(new ChatMessage(ChatMessageRole.User, promptContent));
                _logger.LogInformation($"User prompt: {promptContent}");

                // 4. Send to OpenAPI Chat Completion
                var gptResponse = await _openAIApiFacade.CreateChatCompletionAsync(prompts, OpenAI_API.Models.Model.ChatGPTTurbo, 0, 1, null, 2000, 0, 0);

                // 5. Extract OpenAPI Response Content and return response
                var responseContent = gptResponse.Choices[0].Message.Content;

                // 6.Deserialize the JSON response into a ChatResult object
                if (responseContent.Contains("NotEnoughConditions")) {
                    return null;
                } else {
                    var chatResult = JsonConvert.DeserializeObject<List<TestCasesGenerationResponse>>(responseContent);
                    _logger.LogInformation($"Deserialized response: {chatResult}");
                    return chatResult;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                throw;
            }
        }
    }
}
