﻿namespace NedAI.API.TestCasesGeneration
{
    public class IRefinementConfig
    {
        public bool onlyPositiveScenarios { get; set; }
        public bool onlyNegativeScenarios { get; set; }
    }
}
