﻿
namespace NedAI.API.TestCasesGeneration
{
    public interface ITestCasesGenerationService
    {
        public Task<List<TestCasesGenerationResponse>> GenerationTestCasesAsync(TestCasesGenerationRequest request);
    }
}
