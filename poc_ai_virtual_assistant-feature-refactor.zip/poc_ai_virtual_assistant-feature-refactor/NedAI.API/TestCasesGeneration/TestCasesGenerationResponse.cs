﻿namespace NedAI.API.TestCasesGeneration
{
    public class TestCasesGenerationResponse
    {
        public string Scenario { get; set; }
        public string Given { get; set; }
        public string When { get; set; }
        public string Then { get; set; }

        public List<string> And { get; set; }
        public List<Dictionary<string, object>> Examples { get; set; }
    }
}
