﻿namespace NedAI.API.TestCasesGeneration
{
    public class TestCasesGenerationRequest
    {
        public string conditions { get; set; }
        public string noOfTestCases { get; set; }
        public IRefinementConfig refinementOptions { get; set; }
    }
}
