﻿namespace NedAI.API.TestCasesGeneration
{
    public class UserPrompts
    {
        public const string POSITIVE_SCENARIOS_ONLY = $"\nGenerate positive test cases only.";
        public const string NEGATIVE_SCENARIOS_ONLY = $"\nGenerate negative test cases only.";
    }
}
