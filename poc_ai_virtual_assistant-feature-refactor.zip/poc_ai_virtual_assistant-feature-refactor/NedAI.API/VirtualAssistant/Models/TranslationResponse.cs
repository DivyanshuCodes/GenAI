namespace NedAI.API.VirtualAssistant.Models
{
    public class TranslationResponse
    {
    public string InputText { get; set; }
    public string TranslatedText { get; set; }
    }
    
}
