﻿namespace NedAI.API.VirtualAssistant.Models
{
    public static class CategoryType
    {
        public const string ACCOUNT = "Account";
        public const string CREDIT_CARD = "CreditCard";
        public const string LOAN = "Loan";
        public const string INSURANCE = "Insurance";
        public const string INVESTMENT = "Investment";
        public const string ACCOUNT_BALANCE_CHECK = "AccountBalanceCheck";
        public const string ACCOUNT_TRANSACTIONS_HISTORY_CHECK = "TransactionHistoryCheck";
        public const string DUE_DATE_CHECK = "DueDateCheck";
        public const string DUE_AMOUNT_CHECK = "DueAmountCheck";
        public const string EMI_DUE_DATE_CHECK = "EMIDueDateCheck";
        public const string EMI_DUE_AMOUNT_CHECK = "EMIDueAmountCheck";
        public const string REMAINING_TENURE_CHECK = "RemainingTenureCheck";
        public const string TOTAL_COVER_AMOUNT =  "TotalCoverAmount";
        public const string POLICY_START_DATE = "PolicyStartDate";
        public const string NEXT_PREMIUM_DUE_DATE = "NextPremiumDueDate";
        public const string POLICY_PREMIUM_AMOUNT = "PolicyPremiumAmount";
        public const string INVESTMENT_START_DATE = "InvestmentStartDate";
        public const string INVESTMENT_MATURITY_DATE = "InvestmentMaturityDate";
        public const string INVESTMENT_MATURITY_AMOUNT = "InvestmentMaturityAmount";
        public const string INVESTMENT_TYPE = "InvestmentType";
    }
}
