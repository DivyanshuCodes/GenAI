﻿namespace NedAI.API.VirtualAssistant.Models
{
    public class ChatGptVirtualAssistantResponse
    {
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public string AssistantMessage { get; set; }
        public bool UserHasProvidedRequiredParameters { get; set; }
        public List<Parameters> ParameterValueMappings { get; set; }
    }

    public class AssistantMessage
    {
        public bool IsFollowUp { get; set; }
        public string Message { get; set; }
    }

    public class Parameters
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
