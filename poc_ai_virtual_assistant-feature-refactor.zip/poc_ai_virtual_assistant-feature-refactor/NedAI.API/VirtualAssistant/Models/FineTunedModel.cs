﻿namespace NedAI.API.VirtualAssistant.Models
{
    public static class FineTunedModel
    {
        public const string FT_GPT_35_TURBO_0613_1 = "ft:gpt-3.5-turbo-0613:nagarro::7zk1cgtq";
        public const string FT_GPT_35_TURBO_0613_2 = "ft:gpt-3.5-turbo-0613:nagarro::81uw2bg3";
    }
}
