﻿namespace NedAI.API.VirtualAssistant.Models
{
    public class CategoryPromptHandlerResponse
    {
        public CategoryPromptHandlerResponse(string serializedMessage, string assistantMessage, string type)
        {
            SerializedMessage = serializedMessage;
            Type = type;
            AssistantMessage = assistantMessage;
        }

        public string SerializedMessage { get; set; }
        public string AssistantMessage { get; set; }
        public string Type { get; set; }
    }
}
