﻿using OpenAI_API.Chat;

namespace NedAI.API.VirtualAssistant.Models
{
    public class ConversationMessage
    {
        public string Message { get; set; }
        public string Lang {get; set;} // selected language from UI
        public string Prompt { get; set; } = string.Empty;
        public string Role { get; set; }
        public MessageMetadata MessageMetadata { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }

    }


    public class MessageMetadata
    {
        public string Type { get; set; }
    }
}
