﻿namespace NedAI.API.VirtualAssistant.Models
{
    public class Conversation
    {
        public string ConversationId { get; set; }
        public ConversationMessage ConversationMessage { get; set; }
    }

}
