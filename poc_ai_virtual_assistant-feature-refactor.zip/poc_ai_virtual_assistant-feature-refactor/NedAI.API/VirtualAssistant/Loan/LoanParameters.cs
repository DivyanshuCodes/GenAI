﻿namespace NedAI.API.VirtualAssistant.Loan
{
    public static class LoanParameters
    {
        public const string LOAN_NUMBER = "LoanAccountNumber";
    }
}
