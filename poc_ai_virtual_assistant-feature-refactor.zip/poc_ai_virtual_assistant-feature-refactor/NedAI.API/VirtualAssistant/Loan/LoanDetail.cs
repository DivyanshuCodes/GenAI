﻿namespace NedAI.API.VirtualAssistant.Loan
{
    public class LoanDetail
    {
        public string LoanNumber { get; set; }
        public string LoanType { get; set; }
        public DateTime EMIDueDate { get; set; }
        public int EMIDueAmount { get; set; }
        public string Currency { get; set; }
        public int RemainingTenureInMonths { get; set; }
    }
}
