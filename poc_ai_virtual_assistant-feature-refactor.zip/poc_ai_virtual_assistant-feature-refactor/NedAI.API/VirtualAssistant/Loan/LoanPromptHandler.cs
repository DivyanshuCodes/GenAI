﻿using NedAI.API.VirtualAssistant.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace NedAI.API.VirtualAssistant.Loan
{
    public class LoanPromptHandler : ICategoryPromptHandler
    {
        public LoanPromptHandler()
        {
        }

        public CategoryPromptHandlerResponse Handle(ChatGptVirtualAssistantResponse chatGptVirtualAssistantResponse)
        {
            CategoryPromptHandlerResponse categoryPromptHandlerResponse = null;
            try
            {
                var loanData = File.ReadAllText(@"Data\LoanData.json");
                var allloanDetails = JsonConvert.DeserializeObject<List<LoanDetail>>(loanData, new IsoDateTimeConverter { DateTimeFormat = "dd/MM/yyyy" });
                var loanNumber = chatGptVirtualAssistantResponse.ParameterValueMappings
                                            .FirstOrDefault(x => x.Name == LoanParameters.LOAN_NUMBER)
                                            .Value;
                var loanDetail = allloanDetails.FirstOrDefault(x => x.LoanNumber == loanNumber);
                if (loanDetail == null)
                        {
                            categoryPromptHandlerResponse = new CategoryPromptHandlerResponse("Could not find the data you are looking for.", "Could not find the data you are looking for.", "string");
                            return categoryPromptHandlerResponse;
                        }
                switch(chatGptVirtualAssistantResponse.SubCategory)
                {
                    case CategoryType.EMI_DUE_DATE_CHECK:
                        var loanDueDate = $"Your loan due date is  {loanDetail.EMIDueDate}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(loanDueDate, "Your loan due date is **/**/****", "string");
                        break;
                    case CategoryType.EMI_DUE_AMOUNT_CHECK:
                        var loanDueAmount = $"Your loan due amount is  {loanDetail.EMIDueAmount} {loanDetail.Currency}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(loanDueAmount, "Your loan due amount is *** ZAR", "string");
                        break;
                    case CategoryType.REMAINING_TENURE_CHECK:
                        var loanRemainingTenure = $"Your loan remaining tenure is  {loanDetail.RemainingTenureInMonths} months";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(loanRemainingTenure, "Your loan remaining tenure is *** months", "string");
                        break;
                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return categoryPromptHandlerResponse;
        }
    }
}
