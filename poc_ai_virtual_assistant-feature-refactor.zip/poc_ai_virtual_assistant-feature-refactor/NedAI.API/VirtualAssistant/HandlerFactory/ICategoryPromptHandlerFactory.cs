﻿using NedAI.API.Models;

namespace NedAI.API.VirtualAssistant
{
    public interface ICategoryPromptHandlerFactory
    {
        ICategoryPromptHandler GetCategoryPromptHandler(string category);
    }
}
