﻿using NedAI.API.VirtualAssistant.Account;
using NedAI.API.VirtualAssistant.CreditCard;
using NedAI.API.VirtualAssistant.Loan;
using NedAI.API.VirtualAssistant.Insurance;
using NedAI.API.VirtualAssistant.Models;
using NedAI.API.VirtualAssistant.Investments;

namespace NedAI.API.VirtualAssistant
{
    public class CategoryPromptHandlerFactory : ICategoryPromptHandlerFactory
    {
        private readonly ILogger _logger;
        private Dictionary<string, Func<ICategoryPromptHandler>> _categoryPromptHandlers;
        public CategoryPromptHandlerFactory(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<CategoryPromptHandlerFactory>();
        }

        public ICategoryPromptHandler GetCategoryPromptHandler(string category)
        {
            CategoryHandlerDictionaries().TryGetValue(category, out Func<ICategoryPromptHandler> categoryPromptHandler);
            if (categoryPromptHandler == null)
            {
                throw new NotImplementedException();
            }
            _logger.LogInformation($"Found Event Handler : {categoryPromptHandler.GetType().Name}");
            return categoryPromptHandler();
        }

        private Dictionary<string, Func<ICategoryPromptHandler>> CategoryHandlerDictionaries()
        {
            if (_categoryPromptHandlers != null)
                return _categoryPromptHandlers;

            _categoryPromptHandlers = new Dictionary<string, Func<ICategoryPromptHandler>> {
                { CategoryType.ACCOUNT, () => new AccountPromptHandler() },
                { CategoryType.CREDIT_CARD, () => new CreditCardPromptHandler() },
                { CategoryType.LOAN, () => new LoanPromptHandler() },
                { CategoryType.INSURANCE, () => new InsurancePromptHandler() },
                { CategoryType.INVESTMENT, () => new InvestmentPromptHandler() },
            };
            return _categoryPromptHandlers;
        }
    }
}
