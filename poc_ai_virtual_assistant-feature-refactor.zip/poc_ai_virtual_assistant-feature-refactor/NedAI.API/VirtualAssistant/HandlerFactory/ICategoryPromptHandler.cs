﻿using NedAI.API.VirtualAssistant.Models;

namespace NedAI.API.VirtualAssistant
{
    public interface ICategoryPromptHandler
    {
        CategoryPromptHandlerResponse Handle(ChatGptVirtualAssistantResponse chatGptVirtualAssistantResponse);
    }
}
