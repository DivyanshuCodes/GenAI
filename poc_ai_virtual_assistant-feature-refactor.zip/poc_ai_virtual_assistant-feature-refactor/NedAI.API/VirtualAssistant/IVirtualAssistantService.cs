﻿using NedAI.API.VirtualAssistant.Models;

namespace NedAI.API.VirtualAssistant
{
    public interface IVirtualAssistantService
    {
        Task<ConversationMessage> CreateUpdateConversationAsync(Conversation conversation);

        List<ConversationMessage> GetConversationHistoryByConversationId(string conversationId);
    }
}
