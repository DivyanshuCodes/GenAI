﻿namespace NedAI.API.VirtualAssistant.Investments
{
    public class InvestmentParameters
    {
        public const string INVESTMENT_NUMBER = "InvestmentNumber";
    }
}
