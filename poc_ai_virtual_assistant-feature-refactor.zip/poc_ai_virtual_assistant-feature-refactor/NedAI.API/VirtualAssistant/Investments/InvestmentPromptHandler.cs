﻿using NedAI.API.VirtualAssistant.Models;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json;

namespace NedAI.API.VirtualAssistant.Investments

{
    public class InvestmentPromptHandler: ICategoryPromptHandler
    {

        public InvestmentPromptHandler()
        {
        }

        public CategoryPromptHandlerResponse Handle(ChatGptVirtualAssistantResponse chatGptVirtualAssistantResponse)
        {
            CategoryPromptHandlerResponse categoryPromptHandlerResponse = null;
            try
            {
                var investmentData = File.ReadAllText(@"Data\InvestmentData.json");
                var allInvestmentDetails = JsonConvert.DeserializeObject<List<InvestmentDetail>>(investmentData, new IsoDateTimeConverter { DateTimeFormat = "dd/MM/yyyy" });
                var investmentNumber = chatGptVirtualAssistantResponse.ParameterValueMappings
                                            .FirstOrDefault(x => x.Name == InvestmentParameters.INVESTMENT_NUMBER)
                                            .Value;
                var investmentDetail = allInvestmentDetails.FirstOrDefault(x => x.InvestmentNumber == investmentNumber);
                if (investmentDetail == null)
                {
                    categoryPromptHandlerResponse = new CategoryPromptHandlerResponse("Could not find the data you are looking for.", "Could not find the data you are looking for.", "string");
                    return categoryPromptHandlerResponse;
                }
                switch (chatGptVirtualAssistantResponse.SubCategory)
                {
                    case CategoryType.INVESTMENT_START_DATE:
                        var investmentStartDate = $"Your investment start date is  {investmentDetail.InvestmentStartDate}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(investmentStartDate, "Your investment start date is **/**/****", "string");
                        break;
                    case CategoryType.INVESTMENT_MATURITY_DATE:
                        var nextPremiumDueDate = $"Your investment maturity date is  {investmentDetail.InvestmentMaturityDate}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(nextPremiumDueDate, "Your investment maturity date is **/**/****", "string");
                        break;
                    case CategoryType.INVESTMENT_MATURITY_AMOUNT:
                        var totalCoverAmount = $"Your investment maturity amount is  {investmentDetail.InvestmentMaturityAmount} {investmentDetail.Currency}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(totalCoverAmount, "Your investment maturity amount is *** ZAR", "string");
                        break;
                    case CategoryType.POLICY_PREMIUM_AMOUNT:
                        var policyPremiumAmount = $"Your investment type is  {investmentDetail.InvestmentType}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(policyPremiumAmount, "Your investment type is ***", "string");
                        break;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return categoryPromptHandlerResponse;
        }
    }
}
