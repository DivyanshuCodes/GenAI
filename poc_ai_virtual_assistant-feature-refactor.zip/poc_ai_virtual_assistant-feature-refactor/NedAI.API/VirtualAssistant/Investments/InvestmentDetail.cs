﻿namespace NedAI.API.VirtualAssistant.Investments
{
    public class InvestmentDetail
    {
        public string InvestmentNumber { get; set; }
        public string InvestmentType { get; set; }
        public DateTime InvestmentStartDate { get; set; }
        public string Currency { get; set; }
        public DateTime InvestmentMaturityDate { get; set; }
        public int InvestmentMaturityAmount { get; set; }
    }
}
