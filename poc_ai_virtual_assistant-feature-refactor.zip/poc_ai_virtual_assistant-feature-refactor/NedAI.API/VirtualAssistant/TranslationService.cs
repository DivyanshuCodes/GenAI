using NedAI.API.VirtualAssistant.Models ;
using NedAI.API.Models;
using Newtonsoft.Json;
using OpenAI_API.Chat;
using openai_api_facade;

namespace NedAI.API.VirtualAssistant{

    public class TranslationService : ITranslationService
{
        private ILogger<TranslationService> _logger;
        private readonly HttpClient _httpClient;
         private readonly IOpenAIApiFacade _openAIApiFacade;
        public TranslationService(ILogger<TranslationService> logger,
                                        IHttpClientFactory httpClientFactory,
                                        AppSettings appSettings, IOpenAIApiFacade openAIApiFacade)
        {
            _logger = logger;
            _httpClient = httpClientFactory.CreateClient();
            _httpClient.BaseAddress = new Uri($"{appSettings.NedGPTUrl}");
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
            _openAIApiFacade = openAIApiFacade;
        }

    public async Task<TranslationResponse> TranslateAsync(string srcLang, string dstLang, string message)
    {
        var systemPrompt = await File.ReadAllTextAsync("Data\\TranslationPrompt.txt");
         var formatttedSystemPrompt = string.Format(systemPrompt, srcLang, dstLang);
        return await Translate(formatttedSystemPrompt, message);
    }

    private async Task<TranslationResponse> Translate(string prompt, string userPrompt = "")
        {
            // Make API call to Chat GPT with prompt and userPrompt

            var prompts = new List<ChatMessage> { new ChatMessage(ChatMessageRole.System, prompt) };
            
            try
            {
                if (!string.IsNullOrEmpty(userPrompt))
                {
                    prompts.Add(new ChatMessage(ChatMessageRole.User, userPrompt));
                }  
                // var gptResponse = await _openAIApiFacade.CreateChatCompletionAsync(prompts, OpenAI_API.Models.Model.ChatGPTTurbo0301, 0, 1, null, 2000, 0, 0);
                var gptResponse = await _openAIApiFacade.CreateChatCompletionAsync(prompts, OpenAI_API.Models.Model.ChatGPTTurbo, 0, 1, null, 2000, 0, 0);
                var responseContent = gptResponse.Choices[0].Message.Content;
                _logger.LogInformation($"TS | OpenAI | responseContent: {responseContent}");       
                
                // Deserialize the JSON response into a ChatResult object
                var chatResult = JsonConvert.DeserializeObject<TranslationResponse>(responseContent);

                return chatResult;       
            }
            catch (Exception ex)
            {
                _logger.LogError($"TS | Exception: {ex}");
                throw ex;
            }
        }
    }
}