﻿namespace NedAI.API.VirtualAssistant.Insurance
{
    public class InsuranceDetail
    {
        public string PolicyNumber { get; set; }
        public string InsuranceType { get; set; }
        public DateTime PolicyStartDate { get; set; }
        public int PolicyPremiumAmount { get; set; }
        public string Currency { get; set; }
        public DateTime NextPremiumDueDate { get; set; }
         public int TotalCoverAmount { get; set; }

    }
}
