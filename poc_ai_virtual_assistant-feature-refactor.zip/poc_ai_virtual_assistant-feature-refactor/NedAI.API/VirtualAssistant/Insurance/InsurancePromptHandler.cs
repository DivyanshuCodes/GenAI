﻿using NedAI.API.VirtualAssistant.Insurance;
using NedAI.API.VirtualAssistant.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace NedAI.API.VirtualAssistant.Insurance
{
    public class InsurancePromptHandler : ICategoryPromptHandler
    {
        public InsurancePromptHandler()
        {
        }

        public CategoryPromptHandlerResponse Handle(ChatGptVirtualAssistantResponse chatGptVirtualAssistantResponse)
        {
           CategoryPromptHandlerResponse categoryPromptHandlerResponse = null;
            try
            {
                var insuranceData = File.ReadAllText(@"Data\InsuranceData.json");
                var allinsuranceDetails = JsonConvert.DeserializeObject<List<InsuranceDetail>>(insuranceData, new IsoDateTimeConverter { DateTimeFormat = "dd/MM/yyyy" });
                var policyNumber = chatGptVirtualAssistantResponse.ParameterValueMappings
                                            .FirstOrDefault(x => x.Name == InsuranceParameters.POLICY_NUMBER)
                                            .Value;
                var insuranceDetail = allinsuranceDetails.FirstOrDefault(x => x.PolicyNumber == policyNumber);
                if (insuranceDetail == null)
                        {
                            categoryPromptHandlerResponse = new CategoryPromptHandlerResponse("Could not find the data you are looking for.", "Could not find the data you are looking for.", "string");
                            return categoryPromptHandlerResponse;
                        }
                switch(chatGptVirtualAssistantResponse.SubCategory)
                {
                    case CategoryType.POLICY_START_DATE:
                        var policyStartDate = $"Your insurance policy start date is  {insuranceDetail.PolicyStartDate}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(policyStartDate, "Your insurance policy start date is **/**/****", "string");
                        break;
                    case CategoryType.NEXT_PREMIUM_DUE_DATE:
                        var nextPremiumDueDate = $"Your next premium due date is  {insuranceDetail.NextPremiumDueDate}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(nextPremiumDueDate, "Your next premium due date is **/**/****", "string");
                        break;
                    case CategoryType.TOTAL_COVER_AMOUNT:
                        var totalCoverAmount = $"Your total cover amount is  {insuranceDetail.TotalCoverAmount} {insuranceDetail.Currency}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(totalCoverAmount, "Your total cover amount is *** ZAR", "string");
                        break;
                    case CategoryType.POLICY_PREMIUM_AMOUNT:
                        var policyPremiumAmount = $"Your policy premium amount is  {insuranceDetail.PolicyPremiumAmount} {insuranceDetail.Currency}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(policyPremiumAmount, "Your policy premium amount is *** ZAR", "string");
                        break;
                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return categoryPromptHandlerResponse;
        }
    }
}


