﻿namespace NedAI.API.VirtualAssistant.Insurance
{
    public static class InsuranceParameters
    {
        public const string POLICY_NUMBER = "InsurancePolicyNumber";
    }
}
