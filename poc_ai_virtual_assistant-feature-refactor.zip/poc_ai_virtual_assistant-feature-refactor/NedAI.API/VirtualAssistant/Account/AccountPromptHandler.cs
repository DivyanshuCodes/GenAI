﻿using NedAI.API.VirtualAssistant.Models;
using Newtonsoft.Json;

namespace NedAI.API.VirtualAssistant.Account
{
    public class AccountPromptHandler : ICategoryPromptHandler
    {
        public AccountPromptHandler()
        {
        }

        public CategoryPromptHandlerResponse Handle(ChatGptVirtualAssistantResponse chatGptVirtualAssistantResponse)
        {
            CategoryPromptHandlerResponse categoryPromptHandlerResponse = null;
            try
            {
                string accountNumber = null;
                switch (chatGptVirtualAssistantResponse.SubCategory)
                {
                    case CategoryType.ACCOUNT_BALANCE_CHECK:
                        var accountData = File.ReadAllText(@"Data\AccountData.json");
                        var allAccountDetails = JsonConvert.DeserializeObject<List<AccountDetail>>(accountData);
                        var accountParameterValue = chatGptVirtualAssistantResponse.ParameterValueMappings
                                                    .FirstOrDefault(x => x.Name == AccountParamaters.ACCOUNT_NUMBER);
                        
                        var accountDetail = allAccountDetails.FirstOrDefault(x => x.AccountNumber == accountParameterValue.Value);
                        if (accountDetail == null)
                        {
                            categoryPromptHandlerResponse = new CategoryPromptHandlerResponse("Could not find the data you are looking for.", "Could not find the data you are looking for.", "string");
                            return categoryPromptHandlerResponse;
                        }
                        var accountBalanceWithCurrency = $"Your account balance is {accountDetail.Balance} {accountDetail.Currency}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(accountBalanceWithCurrency, "Your account balance is * ZAR", "string");
                        break;
                    case CategoryType.ACCOUNT_TRANSACTIONS_HISTORY_CHECK:
                        var accountTransactionsData = File.ReadAllText(@"Data\TransactionDataAccount.json");
                        var allAccountTransactionDetails = JsonConvert.DeserializeObject<List<AccountTransaction>>(accountTransactionsData);
                        var transactionParameterValue = chatGptVirtualAssistantResponse.ParameterValueMappings
                                                    .FirstOrDefault(x => x.Name == AccountParamaters.ACCOUNT_NUMBER);
                        
                        var transactionDetails = allAccountTransactionDetails.Where(x => x.AccountNumber == transactionParameterValue.Value);
                        if (transactionDetails == null)
                        {
                            categoryPromptHandlerResponse = new CategoryPromptHandlerResponse("Could not find the data you are looking for.", "Could not find the data you are looking for.", "string");
                            return categoryPromptHandlerResponse;
                        }
                        var transactionHistory = JsonConvert.SerializeObject(transactionDetails);
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(transactionHistory, "Your transaction history has been fetched.", "array");
                        break;
                }
                
            }
            catch (Exception ex)
            {

            }
            return categoryPromptHandlerResponse;
        }
    }
}
