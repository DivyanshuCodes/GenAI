﻿namespace NedAI.API.VirtualAssistant.Account
{
    public static class AccountParamaters
    {
        public const string ACCOUNT_NUMBER = "AccountNumber";
    }
}
