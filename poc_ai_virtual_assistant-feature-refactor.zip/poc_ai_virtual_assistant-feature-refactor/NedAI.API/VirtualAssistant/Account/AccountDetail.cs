﻿namespace NedAI.API.VirtualAssistant.Account
{
    public class AccountDetail
    {
        public string AccountNumber { get; set; }
        public string Balance { get; set; }
        public string Currency { get; set; }
    }
}
