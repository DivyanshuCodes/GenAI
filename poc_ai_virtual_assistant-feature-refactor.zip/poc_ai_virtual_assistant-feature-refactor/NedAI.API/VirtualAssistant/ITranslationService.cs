using NedAI.API.VirtualAssistant.Models ;
namespace NedAI.API.VirtualAssistant{
public interface ITranslationService
{
   
    Task<TranslationResponse> TranslateAsync(string srcLang, string dstLang, string message);
    
}
}