﻿using NedAI.API.VirtualAssistant.CreditCard;
using NedAI.API.VirtualAssistant.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace NedAI.API.VirtualAssistant.CreditCard
{
    public class CreditCardPromptHandler : ICategoryPromptHandler
    {
        public CreditCardPromptHandler()
        {
        }

        public CategoryPromptHandlerResponse Handle(ChatGptVirtualAssistantResponse chatGptVirtualAssistantResponse)
        {
            CategoryPromptHandlerResponse categoryPromptHandlerResponse = null;
            try
            {
                var creditCardData = File.ReadAllText(@"Data\CreditCardData.json");
                var allCreditCardDetails = JsonConvert.DeserializeObject<List<CreditCardDetail>>(creditCardData, new IsoDateTimeConverter { DateTimeFormat = "dd/MM/yyyy" });
                var creditCardNumber = chatGptVirtualAssistantResponse.ParameterValueMappings
                                            .FirstOrDefault(x => x.Name == CreditCardParameters.CREDIT_CARD_NUMBER)
                                            .Value;
                var creditCardDetail = allCreditCardDetails.FirstOrDefault(x => x.CreditCardNumber == creditCardNumber);
                if (creditCardDetail == null)
                        {
                            categoryPromptHandlerResponse = new CategoryPromptHandlerResponse("Could not find the data you are looking for.", "Could not find the data you are looking for.", "string");
                            return categoryPromptHandlerResponse;
                        }
                switch(chatGptVirtualAssistantResponse.SubCategory)
                {
                    case CategoryType.DUE_DATE_CHECK:
                        var creditCardDueDate = $"Your credit card due date is  {creditCardDetail.DueDate}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(creditCardDueDate, "Your credit card due date is **/**/****", "string");
                        break;
                    case CategoryType.DUE_AMOUNT_CHECK:
                        var creditCardDueAmount = $"Your credit card due amount is  {creditCardDetail.DueAmount} {creditCardDetail.Currency}";
                        categoryPromptHandlerResponse = new CategoryPromptHandlerResponse(creditCardDueAmount, "Your credit card due amount is *** ZAR", "string");
                        break;
                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return categoryPromptHandlerResponse;
        }
    }
}
