﻿namespace NedAI.API.VirtualAssistant.CreditCard
{
    public static class CreditCardParameters
    {
        public const string CREDIT_CARD_NUMBER = "CreditCardNumber";
    }
}
