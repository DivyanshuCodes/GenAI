﻿namespace NedAI.API.VirtualAssistant.CreditCard
{
    public class CreditCardDetail
    {
        public string CreditCardNumber { get; set; }
        public DateTime DueDate { get; set; }
        public int DueAmount { get; set; }
        public string Currency { get; set; }
    }
}
