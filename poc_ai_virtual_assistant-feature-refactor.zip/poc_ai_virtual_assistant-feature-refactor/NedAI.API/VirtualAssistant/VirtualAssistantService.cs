﻿using Microsoft.Extensions.Caching.Memory;
using NedAI.API.Models;
using NedAI.API.VirtualAssistant.Models;
using Newtonsoft.Json;
using OpenAI_API;
using OpenAI_API.Chat;
using openai_api_facade;
using System.Data;
using Conversation = NedAI.API.VirtualAssistant.Models.Conversation;
using System.Formats.Tar;

namespace NedAI.API.VirtualAssistant
{
    public class VirtualAssistantService : IVirtualAssistantService
    {
        private ILogger<VirtualAssistantService> _logger;
        private readonly IMemoryCache _memoryCache;
        private readonly HttpClient _httpClient;
        private readonly ICategoryPromptHandlerFactory _categoryPromptHandlerFactory;
        private readonly IOpenAIAPI _openAIAPI;
        private readonly IOpenAIApiFacade _openAIApiFacade;

        private readonly ITranslationService _translationService;
        
        private string additionalUserPrompt = "Follow the instructions in the System role always. Keep those instructions in context all the time.\n";
        public VirtualAssistantService(ILogger<VirtualAssistantService> logger,
                                        IHttpClientFactory httpClientFactory,
                                        AppSettings appSettings,
                                        IMemoryCache memoryCache,
                                        ICategoryPromptHandlerFactory categoryPromptHandlerFactory,
                                        //IOpenAIAPI openAIAPI,
                                        IOpenAIApiFacade openAIApiFacade,
                                        ITranslationService translationService) 
        {
            _logger = logger;
            _httpClient = httpClientFactory.CreateClient();
            _httpClient.BaseAddress = new Uri($"{appSettings.NedGPTUrl}");
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
            _memoryCache = memoryCache;
            _categoryPromptHandlerFactory = categoryPromptHandlerFactory;
            //_openAIAPI = openAIAPI;
            _openAIApiFacade = openAIApiFacade;
             _translationService = translationService;
            //_openAIAPI.Auth = new APIAuthentication("");
        }

        public async Task<ConversationMessage> CreateUpdateConversationAsync(Conversation conversation)
        {
            _logger.LogInformation($"__________ START __________ ");
            ConversationMessage conversationMessage = null;

            try
            {
                // Validation

                if (conversation==null) throw new ArgumentNullException(nameof(conversation));

                // 2. Check if existing conversation
                bool isConversationActive = _memoryCache.TryGetValue(conversation.ConversationId, out ConversationHistory conversationHistory);
                
                //Translate user's message to English
                var sourceLang= string.IsNullOrEmpty(conversation.ConversationMessage.Lang) ? "en" : conversation.ConversationMessage.Lang; 
                var translatedMessage = conversation.ConversationMessage.Message;

                if (!string.IsNullOrEmpty(conversation.ConversationMessage.Lang) && !(conversation.ConversationMessage.Lang.ToLower() == "english")) {
                    _logger.LogInformation($"TRANSLATION_1 - START");
                    var targetLang = "English" ;
                    var userMessage = conversation.ConversationMessage.Message;
                    _logger.LogInformation($"SOURCE_LANG: {sourceLang} | TARGET_LANG: {targetLang}");
                    _logger.LogInformation($"INPUT: {userMessage}");

                    // Call the Translation service and wait for the response
                    var translationResponse = await _translationService.TranslateAsync(sourceLang, targetLang, userMessage); // string srcLang, string dstLang, string message
                    translatedMessage = translationResponse.TranslatedText;

                    //Logger Translation from selected language to English
                    _logger.LogInformation($"TRANSLATED: {translationResponse.TranslatedText}");
                    _logger.LogInformation($"TRANSLATION_1 - END");
                }
                var virtualAssistantSystemPromptString = File.ReadAllText(@"Data\VirtualAssistantSystemPrompt4.txt");
                var systemPrompt = new ChatMessage(ChatMessageRole.System, virtualAssistantSystemPromptString);
                var userPrompt = new ChatMessage(ChatMessageRole.User, conversation.ConversationMessage.Message);


                if (!isConversationActive)
                {
                    conversationHistory = new ConversationHistory();
                    conversationHistory.ConversationMessageQueue.Enqueue(new ConversationMessage
                    {
                        Message = systemPrompt.Content,
                        Prompt = systemPrompt.Content,
                        MessageMetadata = new MessageMetadata
                        {
                            Type = "string"
                        },
                        Role = ChatMessageRole.System,
                        SubCategory = ""
                    });
                }
                    var usrPromt = new ConversationMessage
                    {
                        Message = userPrompt.Content,
                        Prompt = userPrompt.Content,
                        MessageMetadata = new MessageMetadata
                        {
                            Type = "string"
                        },
                        Role = ChatMessageRole.User,
                        SubCategory = ""
                    };                  


                //var prompts = conversationHistory.ConversationMessageQueue.Select(x => new GPTChatMessage
                //{
                //    Content = x.Prompt,
                //    Role = x.Role,
                //    Name = "VirtualAssistant"
                //}).ToList();

                var prompts = conversationHistory.ConversationMessageQueue.Select(x => new ChatMessage
                {
                    Content = x.Prompt,
                    Role = ChatMessageRole.FromString(x.Role),
                    Name = "VirtualAssistant"
                }).ToList();

                prompts.Add(new ChatMessage
                {
                    Content = translatedMessage,
                    Role = ChatMessageRole.User,
                    Name = "VirtualAssistant"
                });


                //prompts.Add(systemPrompt);

                //var prompts = new List<GPTChatMessage> { systemPrompts, userPrompt };
                // 3 Call ChatGPT API
                var gptResponse = await _openAIApiFacade.CreateChatCompletionAsync(prompts, FineTunedModel.FT_GPT_35_TURBO_0613_2, 0, 1, null, 2000, 0, 0);
                //var gptResponse = await _openAIAPI.Chat.CreateChatCompletionAsync(prompts, FineTunedModel.FT_GPT_35_TURBO_0613_2, 0,1, null, 2000,0,0);
                //var gptResponse = await _httpClient.PostAsJsonAsync("/api/gpt/Completion/gpt4", prompts);
                var responseContent = gptResponse.Choices[0].Message.Content;
                //var responseContent = await gptResponse.Content.ReadAsStringAsync();
                // 4. Extract OpenAPI Response Content and return response
                //if (gptResponse.IsSuccessStatusCode)
                //{
                  //  var chatResult = JsonConvert.DeserializeObject<ChatResult>(responseContent);
                  //  var content = chatResult.Choices.First().Message.Content;
                    var chatGptVirtualAssistantResponse = JsonConvert.DeserializeObject<ChatGptVirtualAssistantResponse>(responseContent);
                    _logger.LogInformation($"VA_Response: {responseContent}"); 
                    CategoryPromptHandlerResponse categoryPromptHandlerResponse;
                    ChatMessage chatMessage = null;
                    
                    if (chatGptVirtualAssistantResponse.UserHasProvidedRequiredParameters)
                    {
                        conversationHistory.ParameterValueMappings = chatGptVirtualAssistantResponse.ParameterValueMappings;
                        var handler = _categoryPromptHandlerFactory.GetCategoryPromptHandler(chatGptVirtualAssistantResponse.Category);
                        _logger.LogInformation($"HANDLER- {handler.ToString()}");
                        categoryPromptHandlerResponse = handler.Handle(chatGptVirtualAssistantResponse);
                        chatMessage = new ChatMessage(ChatMessageRole.Assistant, chatGptVirtualAssistantResponse.AssistantMessage);
                        conversationMessage = new ConversationMessage
                        {
                            Role = ChatMessageRole.Assistant,
                            Message = categoryPromptHandlerResponse.SerializedMessage,
                            Prompt = JsonConvert.SerializeObject(chatGptVirtualAssistantResponse),
                            MessageMetadata = new MessageMetadata
                            {
                                Type = categoryPromptHandlerResponse.Type
                            },
                            Category = chatGptVirtualAssistantResponse.Category,
                            SubCategory = chatGptVirtualAssistantResponse.SubCategory,
                            Lang= sourceLang 
                        };
                    }
                    else
                    {
                        chatMessage = new ChatMessage(ChatMessageRole.Assistant, chatGptVirtualAssistantResponse.AssistantMessage);
                        conversationMessage = new ConversationMessage
                        {
                            Role = ChatMessageRole.Assistant,
                            /*Message = (chatGptVirtualAssistantResponse.Category == "NonBanking" &&
                                      chatGptVirtualAssistantResponse.SubCategory != "Greeting" &&
                                    chatGptVirtualAssistantResponse.SubCategory != "Appreciation" &&
                                    chatGptVirtualAssistantResponse.SubCategory != "Feedback" &&
                                    chatGptVirtualAssistantResponse.SubCategory != "Praise" &&
                                    chatGptVirtualAssistantResponse.SubCategory != "Farewell") ? "I'm sorry, as a banking support AI, I can not answer this question." : chatGptVirtualAssistantResponse.AssistantMessage,*/
                            Message = chatGptVirtualAssistantResponse.AssistantMessage,
                            Prompt = JsonConvert.SerializeObject(chatGptVirtualAssistantResponse),
                            MessageMetadata = new MessageMetadata
                            {
                                Type = "string"
                            },
                            Category = chatGptVirtualAssistantResponse.Category,
                            SubCategory = chatGptVirtualAssistantResponse.SubCategory,
                            Lang= sourceLang 
                        };
                    }

                if (!string.IsNullOrEmpty(conversation.ConversationMessage.Lang) && !(conversation.ConversationMessage.Lang.ToLower() == "english")) {
                    _logger.LogInformation($"TRANSLATION_2 - START");
                    //Translate English response to user prefered lang
                    var sourceLang2= "English" ;
                    var targetLang2= string.IsNullOrEmpty(conversation.ConversationMessage.Lang) ? "en" : conversation.ConversationMessage.Lang;
                    var engResponse = conversationMessage.Message; //chatGptVirtualAssistantResponse.AssistantMessage ;
                
                    _logger.LogInformation($"SOURCE_LANG: {sourceLang2} | TARGET_LANG: {targetLang2}");
                    _logger.LogInformation($"INPUT: {engResponse}");

                    // Call the Translation service and wait for the response
                    var userLangText = await _translationService.TranslateAsync(sourceLang2, targetLang2, engResponse); //string srcLang, string dstLang, string message
                    var userLangResponse = userLangText.TranslatedText;
                    conversationMessage.Message= userLangResponse;

                    //Logger Translation from english to source language
                    _logger.LogInformation($"TRANSLATED: {userLangResponse}");
                    _logger.LogInformation($"TRANSLATION_2 - END");
                }
                conversationHistory.ConversationMessageQueue.Enqueue(usrPromt);
                conversationHistory.ConversationMessageQueue.Enqueue(conversationMessage);
                _memoryCache.Set(conversation.ConversationId, conversationHistory);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception: {ex.ToString()}");
                conversationMessage = new ConversationMessage
                {
                    Role = ChatMessageRole.Assistant,
                    Message = "Apologies, Something went wrong. Please try again later.",
                    Prompt = "",
                    MessageMetadata = new MessageMetadata
                    {
                        Type = "string"
                    },
                    Category = "Error",
                    SubCategory = ""
                };
                throw;
            }
            _logger.LogInformation($"__________ END __________ ");
            return conversationMessage;
        }

        public List<ConversationMessage> GetConversationHistoryByConversationId(string conversationId)
        {
            List<ConversationMessage> conversationMessages = new List<ConversationMessage>();
            bool isConversationActive = _memoryCache.TryGetValue(conversationId, out ConversationHistory conversationHistory);
            if (isConversationActive)
            {
                conversationMessages = conversationHistory.ConversationMessageQueue.Where(x=>x.Role!=ChatMessageRole.System).Select(x =>
                    new ConversationMessage
                    {
                        Message = x.Message,
                        Role = x.Role,
                        MessageMetadata = x.MessageMetadata,
                        Category = x.Category,
                        SubCategory = x.SubCategory
                    }
                ).ToList();
            }
            return conversationMessages;
        }

    }
}

