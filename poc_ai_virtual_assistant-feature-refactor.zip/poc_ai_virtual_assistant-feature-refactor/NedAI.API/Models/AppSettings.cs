﻿namespace NedAI.API.Models
{
    public class AppSettings
    {
        public string NedGPTUrl { get; set; }
    }
}
