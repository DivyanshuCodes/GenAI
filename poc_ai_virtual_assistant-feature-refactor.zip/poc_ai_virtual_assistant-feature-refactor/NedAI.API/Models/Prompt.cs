﻿namespace NedAI.API.Models
{
    public class Prompt
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
