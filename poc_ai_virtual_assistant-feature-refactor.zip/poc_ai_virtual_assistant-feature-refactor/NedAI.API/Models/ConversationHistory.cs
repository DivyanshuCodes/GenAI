﻿using NedAI.API.VirtualAssistant.Models;
using OpenAI_API.Chat;

namespace NedAI.API.Models
{
    public class ConversationHistory
    {
        public ConversationHistory()
        {
            ConversationMessageQueue = new Queue<ConversationMessage>();
            ParameterValueMappings = new List<Parameters>();
        }
        public Queue<ConversationMessage> ConversationMessageQueue { get; set; }
        public List<Parameters> ParameterValueMappings { get; set; }
    }
}
