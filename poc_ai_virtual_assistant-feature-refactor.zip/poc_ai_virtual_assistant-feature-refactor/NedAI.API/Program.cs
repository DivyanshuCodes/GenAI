using NedAI.API.AnalyzeTransactions;
using NedAI.API.Caching;
using NedAI.API.Models;
using NedAI.API.TestCasesGeneration;
using NedAI.API.VirtualAssistant;
using Newtonsoft.Json.Serialization;
using OpenAI_API;
using openai_api_facade;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddMemoryCache();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddControllers().AddNewtonsoftJson(options =>
{
    // Use the recommended settings to maintain compatibility with System.Text.Json
    options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
});
var appConfig = new AppSettings();
builder.Configuration.Bind("AppSettings", appConfig);
builder.Services.AddSingleton(appConfig);
builder.Services.AddHttpClient();
builder.Services.AddTransient<ITransactionService, TransactionService>();
builder.Services.AddTransient<ITranslationService,TranslationService>() ;
builder.Services.AddTransient<IVirtualAssistantService, VirtualAssistantService>();
builder.Services.AddTransient<ICacheService, CacheService>();
builder.Services.AddTransient<ICategoryPromptHandlerFactory, CategoryPromptHandlerFactory>();
builder.Services.AddTransient<IOpenAIAPI, OpenAIAPI>();
builder.Services.AddTransient<IOpenAIApiFacade, OpenAIApiFacade>();
builder.Services.AddTransient<ITestCasesGenerationService, TestCasesGenerationService>();

var configuration = new ConfigurationBuilder()
     .AddJsonFile($"appsettings.json");

builder.Services.AddCors(p => p.AddPolicy("cors", builder =>
{
    builder.WithOrigins("*").AllowAnyMethod().AllowAnyHeader();
}));

var config = configuration.Build();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.UseCors("cors");

app.Run();
