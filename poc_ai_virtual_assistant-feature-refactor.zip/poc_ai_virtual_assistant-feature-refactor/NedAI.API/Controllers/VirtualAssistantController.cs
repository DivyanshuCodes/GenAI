using Microsoft.AspNetCore.Mvc;
using NedAI.API.VirtualAssistant;
using NedAI.API.VirtualAssistant.Models;

namespace NedAI.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VirtualAssistantController : ControllerBase
    {
        private readonly ILogger<VirtualAssistantController> _logger;
        private readonly IVirtualAssistantService _virtualAssistantService;

        
        public VirtualAssistantController(ILogger<VirtualAssistantController> logger, IVirtualAssistantService virtualAssistantService  )
        {
            _logger = logger;
            _virtualAssistantService = virtualAssistantService;
           
        }

        [HttpPost("conversation/{conversationId}")]
        public async Task<ConversationMessage> CreateUpdateConversationAsync(string conversationId, ConversationMessage userMessage)
        {
            try
            {
                var conversation = new Conversation { ConversationId = conversationId, ConversationMessage = userMessage };
                return await _virtualAssistantService.CreateUpdateConversationAsync(conversation);
            }
            catch (FileNotFoundException ex)
            {
                return new ConversationMessage() { Message = "FNF", Category = ex.StackTrace };
            }
            catch (Exception ex)
            {
                return new ConversationMessage() { Message = ex.Message, Category = ex.StackTrace };
            }
        }

        [HttpGet("conversation/{conversationId}")]
        public async Task<List<ConversationMessage>> GetConversationHistoryByConversationId(string conversationId)
        {
            return _virtualAssistantService.GetConversationHistoryByConversationId(conversationId);
        }
    }
}