using Microsoft.AspNetCore.Mvc;
using NedAI.API.TestCasesGeneration;

namespace NedAI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestCaseGenerationController : ControllerBase
    {
        private readonly ILogger<TestCaseGenerationController> _logger;
        private readonly ITestCasesGenerationService _testCasesGenerationService;

        public TestCaseGenerationController(ILogger<TestCaseGenerationController> logger, ITestCasesGenerationService testCasesGenerationService)
        {
            _logger = logger;
            _testCasesGenerationService = testCasesGenerationService;
        }

        [HttpPost]
        [Route("generate")]
        public async Task<List<TestCasesGenerationResponse>> GenerationTestCasesAsync(TestCasesGenerationRequest request)
        {
            return await _testCasesGenerationService.GenerationTestCasesAsync(request);
        }

    }
}
