﻿namespace NedAI.API.Caching
{
    public class CacheService : ICacheService
    {
    }
}
