﻿namespace NedAI.API.Caching
{
    public interface ICacheService
    {
    }
}
