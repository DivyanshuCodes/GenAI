import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TransactionComponent } from './components/transaction/transaction.component';
import { ChatBoxComponent } from './components/chat-box/chat-box.component';
import { AuthGuard } from './guards/auth.guard';
import { CustomInputComponent } from './components/custom-input/custom-input.component';

const routes: Routes = [
  {path:'transaction', component: TransactionComponent, canActivate:[AuthGuard], pathMatch:'full'},
  {path:'', component:ChatBoxComponent, pathMatch:'full'},
  {path:'va', component:ChatBoxComponent, pathMatch:'full'},
  {path:'chatbot', component:ChatBoxComponent, pathMatch:'full'},
  {path:'custominput', component:CustomInputComponent, pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
