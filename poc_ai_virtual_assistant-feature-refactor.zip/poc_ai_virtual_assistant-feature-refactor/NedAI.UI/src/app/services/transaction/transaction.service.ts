import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import baseApiUrl from '../helper';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  constructor(private http: HttpClient) { }

  public getTransactionData(transactionData: any): Observable<any> {
    return this.http.post(`${baseApiUrl}/api/transactions/analyze`, transactionData);
  }
}
