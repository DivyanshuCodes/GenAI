// let baseApiUrl="http://localhost:7004";
let baseApiUrl="https://ned-chat-api.azurewebsites.net";
// let baseApiUrl="https://localhost:7002";
// let baseApiUrl = "http://localhost:5105";
export default baseApiUrl;
