import { Injectable } from '@angular/core';
import { v4 as uuidv4 } from 'uuid';

@Injectable({
  providedIn: 'root'
})
export class ConversationManagementService {

  constructor() { }

  private generateConversationId():string{ 
    const userId=uuidv4();
     this.setConversationId(userId);
     return userId;
   }

  private setConversationId(userId:string):void{
    sessionStorage.setItem('conversationId', userId);
  }

  getSetConversationId():string{
    if(sessionStorage.getItem('conversationId')){
      return sessionStorage.getItem('conversationId') || '';
    }
    else{
     return this.generateConversationId();
    }
  }
}
