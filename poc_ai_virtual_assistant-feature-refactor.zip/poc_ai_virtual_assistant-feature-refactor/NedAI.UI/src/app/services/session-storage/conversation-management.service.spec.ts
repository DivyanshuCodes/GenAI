import { TestBed } from '@angular/core/testing';

import { ConversationManagementService } from './conversation-management.service';

describe('UserIdService', () => {
  let service: ConversationManagementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConversationManagementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
