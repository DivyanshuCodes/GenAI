import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseApiUrl from './helper';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChatresponseService {

  constructor(private http: HttpClient) { }

  getChatResponse(conversationId:string, conversationPayload:any):Observable<any>{
    return this.http.post(`${baseApiUrl}/api/VirtualAssistant/conversation/${conversationId}`,conversationPayload);
  }

  getConversationHistory(conversationId:string):Observable<any> {
    return this.http.get(`${baseApiUrl}/api/VirtualAssistant/conversation/${conversationId}`);
  }
}
