import { Component } from '@angular/core';
import { FormBuilder, FormGroup, } from '@angular/forms';
import { Router } from '@angular/router';
import { TestcaseService } from 'src/app/testcase/testcase.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Clipboard } from '@angular/cdk/clipboard';
@Component({
  selector: 'app-custom-input',
  templateUrl: './custom-input.component.html',
  styleUrls: ['./custom-input.component.css'],
})

export class CustomInputComponent {
  isLoading: boolean = false;
  generateButton: boolean = true;
  inputValue: string = '';
  exampleText: string = `Example:
  To open a bank account in XYZ bank with following criteria-
  1. The applicant must have reached the age of 18 or older.
  2. The applicant must possess South African nationality.
  3. A valid South African Identity Document (ID) or Smart ID Card, in addition to either a passport or driver's   license, is necessary.
  4. Evidence of residing in South Africa, like a utility bill (e.g., electricity or water) or a lease agreement under the applicant's name, is required.
  5. Applicants who do not possess either a South African Identity Document (ID) or a Smart ID Card are not eligible to open an account.
  6. Online account registration can be finalized via the computer-based online banking platform.
  7. Web browsers such as Chrome, Firefox, and Safari are compatible and supported.
  8. Operating systems that are compatible include Windows 10 or newer and MacOS Ventura or later.
  9. You can initiate the account opening process online using either a web application or a mobile app, which are accessible on both Android and iOS devices.`;
  Data:any = [];
  prompt!: FormGroup;
  obj: any = {}
  panelOpenState: boolean = false;
  numberOfTestCase: string = "1";
  constructor(private formbuilder: FormBuilder, private router: Router, private service: TestcaseService, private _snackBar: MatSnackBar, private clipboard: Clipboard) { }
  ngOnInit(): void {
    this.prompt = this.formbuilder.group({
      conditions: [''], noOfTestCases: [''], refinementOptions: this.formbuilder.group({
        onlyPositiveScenarios: [false],
        onlyNegativeScenarios: [false],
      })
    })
  }
  //================================Check box===============================
  onCheckboxChange2(event: any) {
    this.prompt.get('refinementOptions.onlyNegativeScenarios')?.setValue(event.checked);
  }
  onCheckboxChange3(event: any) {
    this.prompt.get('refinementOptions.onlyPositiveScenarios')?.setValue(event.checked);
  }

  //=========================== TestCase Generation======================================
  generate() {
    this.isLoading = true;
    this.generateButton = true;
    this.obj = this.prompt.value;
    this.Data = [];
    this.service.postGenerate(this.obj).subscribe(
      (res: any) => {
        console.log(res);
        this.isLoading = false;
        this.displayResponse(res); // Call the function to display response
        this.generateButton = false;
      },
      (error: any) => {
        console.error('Error:', error);
        this.isLoading = false;
        this.displayErrorMessage();
        this.generateButton = false;
      }
    );
  }
  displayErrorMessage() {
    // Display an error message to the user
    this._snackBar.open('Apologies, something went wrong !!', 'Close');
  }
  displayResponse(response: any) {
    // To display response in output
    if (response) {
      this.Data = response;
    } else {
      this._snackBar.open('Please provide enough conditions to generate the test cases !!', 'Close');
    }
  }

  onClick() {
    this.exampleText = '';
  }
  onInput(event: any) {
    if (event.target.value != '') {
      this.generateButton = false;
    }
    else {
      this.generateButton = true;
    }
  }
  copyInputToClipboard() {
    this.clipboard.copy(this.inputValue);
  }
  copyOutputToClipboard() {
    this.clipboard.copy(JSON.stringify(this.Data));
  }
  getKeys(example: any): string[] {
    return Object.keys(example);
  }
}
