import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { TransactionService } from 'src/app/services/transaction/transaction.service';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css'],
})
export class TransactionComponent {
  transactionData = {
    "categorize": true,
    "fraudDetection": true,
    "fromDate": "09-08-2023",
    "toDate": "10-08-2023"
  }
  filterMultiselectList = [
    {
      'name': 'Categorize',
      'value': 'categorize'
    },
    {
      'name': 'Possible Fraudulent',
      'value': 'fraudAlert'
    }
  ]
  showCategorization = false;
  showFraudAlert = false;
  data: any = [];
  transactions = new FormControl();
  isLoading: boolean = false;
  constructor(private router: Router, private service: TransactionService) { }
  ngOnInit() {
    this.isLoading = true;
    this.service.getTransactionData(this.transactionData).subscribe(
      (data: any) => {
        this.data = data;
        this.isLoading = false;
      }
    )
    this.transactions.valueChanges.subscribe(selectedOption => {

      // this.updateTransaction(selectedOption);
      if (selectedOption.indexOf('categorize') > -1) {
        this.showCategorization = true;
      }
      else {
        this.showCategorization = false;
      }

      if (selectedOption.indexOf('fraudAlert') > -1) {
        this.showFraudAlert = true;
      }
      else {
        this.showFraudAlert = false;
      }

      console.log(selectedOption);

    });
  }
  // updateTransaction(selectedOption: string[]): void {
  //   this.transactionData.categorize = selectedOption.includes('Categorize');
  //   this.transactionData.fraudDetection = selectedOption.includes('Possible Fraudulent');
  // }

  displayedColumns: string[] = [ 'transactionId', 'transactionDate', 'amount', 'description', 'category', 'possibleFraudulent'];

  categoryIcons: { [category: string]: string } = {
    'Shopping': 'shopping_cart',
    'Entertainment': 'theaters',
    'Food & Drinks': 'restaurant',
    'Transportation': 'commute'
  }

  getCategoryIcon(category: string): string {
    const defaultIcon = 'category';
    return this.categoryIcons[category] || defaultIcon;
  }
}
