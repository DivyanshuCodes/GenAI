import { AfterViewInit, Component, ElementRef, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { ViewChild } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ChatresponseService } from 'src/app/services/chatresponse.service';
import { SpeechRecognitionService } from 'src/app/services/speech-recognition.service';
import { Subscription, timer } from 'rxjs';
import { take } from 'rxjs/operators';
import { ConversationManagementService } from 'src/app/services/session-storage/conversation-management.service';

interface Message {
  message: string;
  incoming: boolean;
  messageMetadata: MessageMetadata,
  category: string,
  subCategory: string,
  role: string,
  lang: string 
}

interface MessageMetadata {
  type: string
}


@Component({
  selector: 'app-chat-box',
  templateUrl: './chat-box.component.html',
  styleUrls: ['./chat-box.component.css']
})
export class ChatBoxComponent implements AfterViewInit, OnDestroy, OnInit {
  messages: Message[] = [];
  newMessage: string = '';
  supportedLanguages: string[] = ['Afrikaans', 'Zulu', 'French', 'Xhosa', 'Spanish', 'Swedish', 'English'];
  selectedLanguage: string = 'English' ;
  isListening:boolean=false;
  micActive: boolean = false;
  micActiveDuration: number = 8000;
  chatResponseSub$: Subscription | undefined;
  typing=false;
  dynamicPlaceholder="Type a message"

  private micActiveTimerSubscription: Subscription | undefined;
  private scrollContainer!: HTMLElement;
  private mutationObserver!: MutationObserver | null;

  @Output() menuItemClicked = new EventEmitter<string>();

  @ViewChild('chatContainer', { static: false }) chatContainer!: ElementRef;
  @ViewChild('search', { static: false }) searchBox!: ElementRef;

  constructor(private chatResponse: ChatresponseService, private snackBar: MatSnackBar, 
    private speechRecognitionService: SpeechRecognitionService, private sessionId: ConversationManagementService) { }

  ngOnInit(): void {
    this.speechRecognitionService.listen().subscribe((text: string) => {
      this.newMessage = text;
      this.sendMessage();
    });

    // this.messages=this.getStoredMessages(this.sessionId.getSetConversationId());
    this.getConversationHistory(this.sessionId.getSetConversationId())
  }

  ngAfterViewInit() {
    this.scrollContainer = this.chatContainer.nativeElement;
    this.scrollToBottom();
    this.observeNewMessages();
  }

  scrollToBottom() {
    this.scrollContainer.scrollTop = this.scrollContainer.scrollHeight;
  }

  observeNewMessages() {
    this.mutationObserver = new MutationObserver(() => {
      this.scrollToBottom();
    });

    this.mutationObserver.observe(this.scrollContainer, { childList: true });
  }

  sendMessage(): void {
    if (this.newMessage) {
      const message: Message = {
        message: this.newMessage,
        incoming: false,
        messageMetadata: {
          type: 'string'
        },
        category: 'userPrompt',
        subCategory: 'userPrompt',
        role: 'user',
        lang: this.selectedLanguage
      };
      this.messages.push(message);
      this.saveChatToSessionStorage(message);
      this.getResponse(this.newMessage);
      this.newMessage = '';
    }
  }

  transactionData:any=[];
  private getResponse(message:string):void{
    this.typing=true;
    this.setUnsetPlaceholder(false);
    const id = this.sessionId.getSetConversationId();
    const payload = {
      message: message,
      role: 'User',
      messageMetadata: {
        type: 'string'
      },
      category: '',
      subCategory: '',
      lang: this.selectedLanguage
    }

    this.chatResponseSub$ = this.chatResponse.getChatResponse(id, payload).subscribe(
      (data:any) =>{
        this.typing=false;
        this.setUnsetPlaceholder(true);
        if(data.message){
          const assistantMessage: Message = {
            message: data.message,
            incoming: true,
            category: data.category,
            subCategory: data.subCategory,
            messageMetadata: data.messageMetadata,
            role: data.role,
            lang: data.lang
          };
          this.saveChatToSessionStorage(assistantMessage);
          this.messages.push(assistantMessage);
          
          if(data.messageMetadata.type == 'array' && data.subCategory == 'TransactionHistoryCheck'){
            this.transactionData=JSON.parse(assistantMessage.message);
          }
          setTimeout(() => {
            this.searchBox.nativeElement.focus();  
          }, 0);
        }
      },
      (error) => (response: any) => {
        this.typing=false;
        this.setUnsetPlaceholder(true);
        console.log(response);
        this.snackBar.open('Something went wrong!', '', {
          duration: 5000,
        });
        this.searchBox.nativeElement.focus();
      }
    )
  }

  private saveChatToSessionStorage(message:Message):void{
      const conversationId=this.sessionId.getSetConversationId();
      // const storedMessages = this.getStoredMessages(conversationId);
      // storedMessages.push(message);
      // sessionStorage.setItem(conversationId, JSON.stringify(storedMessages));
  }

  private getConversationHistory(conversationId:string){
    this.chatResponseSub$ = this.chatResponse.getConversationHistory(conversationId).subscribe(
      (data:any) =>{
        if(data){
          this.messages = data;
          let transactionHistory = this.messages.find(x=>x.role == 'assistant' && x.messageMetadata.type == 'array' && x.subCategory == 'TransactionHistoryCheck');
          if(transactionHistory) {
            this.transactionData=JSON.parse(transactionHistory.message);
          }
        }
      },
      (error) => (response: any) => {
        console.log(response);
        this.snackBar.open('Something went wrong!', '', {
          duration: 5000,
        });
      }
    )
  }

  toggleListen(): void {
    if (!this.isListening) {
      this.startMicActiveTimer();
      this.speechRecognitionService.start();
    } else {
      this.stopMicActiveTimer();
      this.speechRecognitionService.stop();
     
    }
    this.isListening = !this.isListening;
  }

  private startMicActiveTimer(): void {
    this.micActive = true;
    this.micActiveTimerSubscription = timer(this.micActiveDuration).pipe(take(1)).subscribe(() => {
      this.stopMicActiveTimer();
      this.isListening=false;
    });
  }

  private stopMicActiveTimer(): void {
    this.micActive = false;
    if (this.micActiveTimerSubscription) {
      this.micActiveTimerSubscription.unsubscribe();
    }
  }

    // Function to clear the chat
    clearChat(): void {
      this.messages = [];
    }
  

  private setUnsetPlaceholder(set:boolean){
    if(set){
      this.dynamicPlaceholder="Type a message"
    }
    else{
      this.dynamicPlaceholder=""
    }
  }

  handleMenuItemClick(option: string): void {
    this.menuItemClicked.emit(option);
  }

  ngOnDestroy() {
    if (this.mutationObserver) {
      this.mutationObserver.disconnect();
    }
    if (this.micActiveTimerSubscription) {
      this.micActiveTimerSubscription.unsubscribe();
    }
    if (this.chatResponseSub$) {
      this.chatResponseSub$.unsubscribe();
    }
    this.stopMicActiveTimer();
  }
  
}
