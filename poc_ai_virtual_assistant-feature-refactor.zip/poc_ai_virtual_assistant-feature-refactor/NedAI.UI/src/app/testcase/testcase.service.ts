import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseApiUrl from '../services/helper';

@Injectable({
  providedIn: 'root'
})
export class TestcaseService {
  //We need to catch it from helper
  constructor(private http: HttpClient) { }
  postGenerate(userInput:any){
  return this.http.post(`${baseApiUrl}/api/TestCaseGeneration/generate`, userInput);
  }
}
